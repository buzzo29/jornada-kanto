const { onSchedule } = require('firebase-functions/v2/scheduler');
const logger = require('firebase-functions/logger');
const admin = require('firebase-admin');
admin.initializeApp();
const db = admin.firestore();

/* ---------------------------------------------------
   DADOS DO JOGO (gerados a partir do pokemon-ginasio.html —
   se adicionar pokémons/tipos novos no jogo, gere de novo esse trecho)
--------------------------------------------------- */
const SPECIES = {
  bulbasaur:{name:'Bulbasaur', types:['Grass','Poison'], bst:318},
  charmander:{name:'Charmander', types:['Fire'], bst:309},
  squirtle:{name:'Squirtle', types:['Water'], bst:314},
  weedle:{name:'Weedle', types:['Bug','Poison'], bst:195},
  caterpie:{name:'Caterpie', types:['Bug'], bst:195},
  ratata:{name:'Ratata', types:['Normal'], bst:253},
  pidgey:{name:'Pidgey', types:['Normal','Flying'], bst:251},
  mankey:{name:'Mankey', types:['Fighting'], bst:305},
  spearow:{name:'Spearow', types:['Normal','Flying'], bst:262},
  nidoranm:{name:'Nidoran (M)', types:['Poison'], bst:273},
  oddish:{name:'Oddish', types:['Grass','Poison'], bst:320},
  geodude:{name:'Geodude', types:['Rock','Ground'], bst:300},
  onix:{name:'Onix', types:['Rock','Ground'], bst:385},
  ivysaur:{name:'Ivysaur', types:['Grass','Poison'], bst:405},
  venusaur:{name:'Venusaur', types:['Grass','Poison'], bst:525},
  charmeleon:{name:'Charmeleon', types:['Fire'], bst:405},
  charizard:{name:'Charizard', types:['Fire','Flying'], bst:534},
  wartortle:{name:'Wartortle', types:['Water'], bst:405},
  blastoise:{name:'Blastoise', types:['Water'], bst:530},
  kakuna:{name:'Kakuna', types:['Bug','Poison'], bst:205},
  beedrill:{name:'Beedrill', types:['Bug','Poison'], bst:395},
  metapod:{name:'Metapod', types:['Bug'], bst:205},
  butterfree:{name:'Butterfree', types:['Bug','Flying'], bst:395},
  raticate:{name:'Raticate', types:['Normal'], bst:413},
  pidgeotto:{name:'Pidgeotto', types:['Normal','Flying'], bst:349},
  pidgeot:{name:'Pidgeot', types:['Normal','Flying'], bst:479},
  primeape:{name:'Primeape', types:['Fighting'], bst:455},
  fearow:{name:'Fearow', types:['Normal','Flying'], bst:442},
  nidorino:{name:'Nidorino', types:['Poison'], bst:335},
  gloom:{name:'Gloom', types:['Grass','Poison'], bst:395},
  sandshrew:{name:'Sandshrew', types:['Ground'], bst:300},
  sandslash:{name:'Sandslash', types:['Ground'], bst:450},
  clefairy:{name:'Clefairy', types:['Normal'], bst:323},
  jigglypuff:{name:'Jigglypuff', types:['Normal'], bst:270},
  zubat:{name:'Zubat', types:['Poison','Flying'], bst:245},
  golbat:{name:'Golbat', types:['Poison','Flying'], bst:455},
  paras:{name:'Paras', types:['Bug','Grass'], bst:285},
  parasect:{name:'Parasect', types:['Bug','Grass'], bst:405},
  meowth:{name:'Meowth', types:['Normal'], bst:290},
  persian:{name:'Persian', types:['Normal'], bst:440},
  bellsprout:{name:'Bellsprout', types:['Grass','Poison'], bst:300},
  weepinbell:{name:'Weepinbell', types:['Grass','Poison'], bst:390},
  abra:{name:'Abra', types:['Psychic'], bst:310},
  kadabra:{name:'Kadabra', types:['Psychic'], bst:400},
  staryu:{name:'Staryu', types:['Water'], bst:340},
  starmie:{name:'Starmie', types:['Water','Psychic'], bst:520},
  growlithe:{name:'Growlithe', types:['Fire'], bst:350},
  vulpix:{name:'Vulpix', types:['Fire'], bst:299},
  ekans:{name:'Ekans', types:['Poison'], bst:288},
  arbok:{name:'Arbok', types:['Poison'], bst:448},
  diglett:{name:'Diglett', types:['Ground'], bst:265},
  dugtrio:{name:'Dugtrio', types:['Ground'], bst:425},
  magnemite:{name:'Magnemite', types:['Electric'], bst:325},
  magneton:{name:'Magneton', types:['Electric'], bst:465},
  drowzee:{name:'Drowzee', types:['Psychic'], bst:328},
  hypno:{name:'Hypno', types:['Psychic'], bst:483},
  nidoranf:{name:'Nidoran (F)', types:['Poison'], bst:275},
  nidorina:{name:'Nidorina', types:['Poison'], bst:365},
  venonat:{name:'Venonat', types:['Bug','Poison'], bst:305},
  venomoth:{name:'Venomoth', types:['Bug','Poison'], bst:450},
  voltorb:{name:'Voltorb', types:['Electric'], bst:330},
  pikachu:{name:'Pikachu', types:['Electric'], bst:320},
  raichu:{name:'Raichu', types:['Electric'], bst:485},
  poliwag:{name:'Poliwag', types:['Water'], bst:300},
  poliwhirl:{name:'Poliwhirl', types:['Water'], bst:385},
  tentacool:{name:'Tentacool', types:['Water','Poison'], bst:335},
  tentacruel:{name:'Tentacruel', types:['Water','Poison'], bst:515},
  machop:{name:'Machop', types:['Fighting'], bst:305},
  machoke:{name:'Machoke', types:['Fighting'], bst:405},
  doduo:{name:'Doduo', types:['Normal','Flying'], bst:310},
  dodrio:{name:'Dodrio', types:['Normal','Flying'], bst:470},
  ponyta:{name:'Ponyta', types:['Fire'], bst:410},
  rapidash:{name:'Rapidash', types:['Fire'], bst:500},
  slowpoke:{name:'Slowpoke', types:['Water','Psychic'], bst:315},
  slowbro:{name:'Slowbro', types:['Water','Psychic'], bst:490},
  magikarp:{name:'Magikarp', types:['Water'], bst:200},
  gyarados:{name:'Gyarados', types:['Water','Flying'], bst:540},
  grimer:{name:'Grimer', types:['Poison'], bst:325},
  muk:{name:'Muk', types:['Poison'], bst:500},
  tauros:{name:'Tauros', types:['Normal'], bst:490},
  psyduck:{name:'Psyduck', types:['Water'], bst:320},
  golduck:{name:'Golduck', types:['Water'], bst:500},
  krabby:{name:'Krabby', types:['Water'], bst:325},
  kingler:{name:'Kingler', types:['Water'], bst:475},
  horsea:{name:'Horsea', types:['Water'], bst:295},
  seadra:{name:'Seadra', types:['Water'], bst:440},
  goldeen:{name:'Goldeen', types:['Water'], bst:320},
  seaking:{name:'Seaking', types:['Water'], bst:450},
  shellder:{name:'Shellder', types:['Water'], bst:305},
  exeggcute:{name:'Exeggcute', types:['Grass','Psychic'], bst:325},
  cubone:{name:'Cubone', types:['Ground'], bst:320},
  marowak:{name:'Marowak', types:['Ground'], bst:425},
  victreebel:{name:'Victreebel', types:['Grass','Poison'], bst:490},
  tangela:{name:'Tangela', types:['Grass'], bst:435},
  vileplume:{name:'Vileplume', types:['Grass','Poison'], bst:490},
  koffing:{name:'Koffing', types:['Poison'], bst:305},
  weezing:{name:'Weezing', types:['Poison'], bst:490},
  gastly:{name:'Gastly', types:['Ghost','Poison'], bst:310},
  haunter:{name:'Haunter', types:['Ghost','Poison'], bst:405},
  ditto:{name:'Ditto', types:['Normal'], bst:288},
  lickitung:{name:'Lickitung', types:['Normal'], bst:385},
  rhyhorn:{name:'Rhyhorn', types:['Ground','Rock'], bst:345},
  rhydon:{name:'Rhydon', types:['Ground','Rock'], bst:485},
  seel:{name:'Seel', types:['Water'], bst:325},
  dewgong:{name:'Dewgong', types:['Water'], bst:475},
  farfetchd:{name:"Farfetch'd", types:['Normal','Flying'], bst:377},
  kangaskhan:{name:'Kangaskhan', types:['Normal'], bst:490},
  scyther:{name:'Scyther', types:['Bug','Flying'], bst:470},
  omanyte:{name:'Omanyte', types:['Rock','Water'], bst:355},
  omastar:{name:'Omastar', types:['Rock','Water'], bst:495},
  kabuto:{name:'Kabuto', types:['Rock','Water'], bst:355},
  kabutops:{name:'Kabutops', types:['Rock','Water'], bst:495},
  electrode:{name:'Electrode', types:['Electric'], bst:480},
  magmar:{name:'Magmar', types:['Fire'], bst:495},
  lapras:{name:'Lapras', types:['Water'], bst:535},
  porygon:{name:'Porygon', types:['Normal'], bst:395},
  eevee:{name:'Eevee', types:['Normal'], bst:325},
  snorlax:{name:'Snorlax', types:['Normal'], bst:540},
  chansey:{name:'Chansey', types:['Normal'], bst:450},
  hitmonlee:{name:'Hitmonlee', types:['Fighting'], bst:455},
  hitmonchan:{name:'Hitmonchan', types:['Fighting'], bst:455},
  pinsir:{name:'Pinsir', types:['Bug'], bst:500},
  electabuzz:{name:'Electabuzz', types:['Electric'], bst:490},
  aerodactyl:{name:'Aerodactyl', types:['Rock','Flying'], bst:515},
  alakazam:{name:'Alakazam', types:['Psychic'], bst:500},
  mrmime:{name:'Mr. Mime', types:['Psychic'], bst:460},
  arcanine:{name:'Arcanine', types:['Fire'], bst:555},
  nidoqueen:{name:'Nidoqueen', types:['Poison','Ground'], bst:505},
  nidoking:{name:'Nidoking', types:['Poison','Ground'], bst:505},
  graveler:{name:'Graveler', types:['Rock','Ground'], bst:425},
  dratini:{name:'Dratini', types:['Dragon'], bst:300},
  dragonair:{name:'Dragonair', types:['Dragon'], bst:420},
  dragonite:{name:'Dragonite', types:['Dragon','Flying'], bst:600},
  jynx:{name:'Jynx', types:['Ice','Psychic'], bst:455},
  exeggutor:{name:'Exeggutor', types:['Grass','Psychic'], bst:520},
  clefable:{name:'Clefable', types:['Normal'], bst:483},
  wigglytuff:{name:'Wigglytuff', types:['Normal'], bst:435},
  ninetales:{name:'Ninetales', types:['Fire'], bst:505},
  poliwrath:{name:'Poliwrath', types:['Water','Fighting'], bst:510},
  cloyster:{name:'Cloyster', types:['Water','Ice'], bst:525},
  machamp:{name:'Machamp', types:['Fighting'], bst:505},
  golem:{name:'Golem', types:['Rock','Ground'], bst:495},
  gengar:{name:'Gengar', types:['Ghost','Poison'], bst:500},
  moltres:{name:'Moltres', types:['Fire','Flying'], bst:580},
  zapdos:{name:'Zapdos', types:['Electric','Flying'], bst:580},
  articuno:{name:'Articuno', types:['Ice','Flying'], bst:580},
  vaporeon:{name:'Vaporeon', types:['Water'], bst:525},
  jolteon:{name:'Jolteon', types:['Electric'], bst:525},
  flareon:{name:'Flareon', types:['Fire'], bst:525}
};

const TYPE_CHART = {
  Normal:{Rock:0.5, Ghost:0},
  Fire:{Grass:2,Bug:2,Rock:0.5,Water:0.5,Fire:0.5,Ice:2},
  Water:{Fire:2,Rock:2,Ground:2,Water:0.5,Grass:0.5},
  Grass:{Water:2,Rock:2,Ground:2,Fire:0.5,Grass:0.5,Poison:0.5,Flying:0.5,Bug:0.5},
  Poison:{Grass:2,Bug:0.5,Rock:0.5,Ground:0.5,Poison:0.5},
  Flying:{Grass:2,Fighting:2,Bug:2,Rock:0.5,Electric:0.5},
  Bug:{Grass:2,Poison:0.5,Fighting:0.5,Flying:0.5,Fire:0.5,Psychic:2},
  Fighting:{Normal:2,Rock:2,Poison:0.5,Flying:0.5,Bug:0.5,Psychic:0.5,Ghost:0,Ice:2},
  Rock:{Fire:2,Flying:2,Bug:2,Fighting:0.5,Ground:0.5,Ice:2},
  Ground:{Fire:2,Rock:2,Poison:2,Grass:0.5,Bug:0.5,Electric:2},
  Psychic:{Fighting:2,Poison:2,Psychic:0.5},
  Electric:{Water:2,Flying:2,Grass:0.5,Electric:0.5,Ground:0},
  Ghost:{Ghost:2,Psychic:2},
  Dragon:{Dragon:2},
  Ice:{Grass:2,Ground:2,Flying:2,Dragon:2,Water:0.5,Ice:0.5,Fire:0.5}
};

/* ---------------------------------------------------
   MOTOR DE BATALHA (mesma lógica do jogo, portada pro servidor)
--------------------------------------------------- */
function typeVsType(atk, def){
  const chart = TYPE_CHART[atk];
  if(!chart) return 1;
  const val = chart[def];
  return (val === undefined) ? 1 : val;
}
function bestMultiplier(atkTypes, defTypes){
  let best = 0;
  atkTypes.forEach(a=>{
    let m = 1;
    defTypes.forEach(d=> m *= typeVsType(a,d));
    if(m > best) best = m;
  });
  return best;
}
function createInstance(speciesId, level){
  const sp = SPECIES[speciesId];
  if(!sp) return null;
  return { speciesId, name:sp.name, types:sp.types, bst:sp.bst, level, maxHp:0, hp:0 };
}
function calcMaxHp(p){ return Math.round(30 + p.level*5 + p.bst/5); }
function calcDamage(attacker, defender, rng){
  const mult = bestMultiplier(attacker.types, defender.types);
  const base = attacker.level*2.5 + attacker.bst/35;
  let defense = Math.pow(defender.bst/300, 0.7);
  if((defender.winsThisBattle||0) > 0){
    const defHpPct = defender.hp / defender.maxHp;
    const minDefenseFactor = 0.15;
    defense = defense * (minDefenseFactor + (1-minDefenseFactor) * defHpPct);
  }
  let levelFactor = 1 + (attacker.level - defender.level) * 0.033;
  levelFactor = Math.max(0.45, Math.min(2.8, levelFactor));
  const dmg = Math.round((base * mult / defense) * levelFactor * (0.75 + rng()*0.5));
  return Math.max(1, dmg);
}
function doExchange(active, enemy, rng){
  const dmgToEnemy = calcDamage(active, enemy, rng);
  const dmgToActive = calcDamage(enemy, active, rng);
  enemy.hp = Math.max(0, enemy.hp - dmgToEnemy);
  active.hp = Math.max(0, active.hp - dmgToActive);
}
function simulateGymBattle(team, enemyTeam, rng){
  team.forEach(p=>{ p.maxHp=calcMaxHp(p); p.hp=p.maxHp; p.winsThisBattle=0; });
  enemyTeam.forEach(p=>{ p.maxHp=calcMaxHp(p); p.hp=p.maxHp; p.winsThisBattle=0; });

  const matchups = [];
  let enemyIndex = 0;
  while(enemyIndex < enemyTeam.length){
    const enemy = enemyTeam[enemyIndex];
    let enemyDefeated = false;
    while(!enemyDefeated){
      const alive = team.filter(p=>p.hp>0);
      if(alive.length===0){ return { win:false, matchups }; }
      const active = alive[0];
      const playerHpBefore = active.hp;
      const enemyHpBefore = enemy.hp;
      const playerAliveBefore = alive.length;
      const enemyAliveBefore = enemyTeam.length - enemyIndex;
      while(active.hp>0 && enemy.hp>0){ doExchange(active, enemy, rng); }
      let enemyFainted = enemy.hp<=0;
      let activeFainted = active.hp<=0;
      let suddenDeath = false;
      let suddenDeathMessage = null;
      if(playerAliveBefore===1 && enemyAliveBefore===1 && enemyFainted && activeFainted){
        suddenDeath = true;
        if(rng() < 0.5){
          active.hp = 1; enemy.hp = 0;
          suddenDeathMessage = `Troca de golpes fatais! ${active.name} mal ficou de pé, mas foi o suficiente pra decidir a batalha!`;
        } else {
          enemy.hp = 1; active.hp = 0;
          suddenDeathMessage = `Troca de golpes fatais! ${enemy.name} resistiu por um triz e virou o resultado no último suspiro!`;
        }
        enemyFainted = enemy.hp<=0;
        activeFainted = active.hp<=0;
      }
      const isTrade = enemyFainted && activeFainted;
      const playerWon = enemyFainted && !activeFainted;
      const playerAliveAfter = activeFainted ? playerAliveBefore - 1 : playerAliveBefore;
      const enemyAliveAfter = enemyFainted ? enemyAliveBefore - 1 : enemyAliveBefore;
      matchups.push({
        player:active.name, playerSpecies:active.speciesId, playerLevel:active.level,
        enemy:enemy.name, enemySpecies:enemy.speciesId, enemyLevel:enemy.level,
        winner: isTrade ? null : (playerWon ? active.name : enemy.name),
        isTrade,
        suddenDeath, suddenDeathMessage,
        playerWon,
        playerHpBefore, playerHpAfter: active.hp, playerMaxHp: active.maxHp,
        enemyHpBefore, enemyHpAfter: enemy.hp, enemyMaxHp: enemy.maxHp,
        playerAliveBefore, playerAliveAfter, playerTeamSize: team.length,
        enemyAliveBefore, enemyAliveAfter, enemyTeamSize: enemyTeam.length
      });
      if(enemyFainted){ enemyDefeated = true; active.winsThisBattle = (active.winsThisBattle||0) + 1; }
    }
    enemyIndex++;
  }
  const teamStillAlive = team.some(p=>p.hp>0);
  return { win: teamStillAlive, matchups };
}
function makeSeededRng(seedStr){
  let h = 1779033703 ^ seedStr.length;
  for(let i=0;i<seedStr.length;i++){
    h = Math.imul(h ^ seedStr.charCodeAt(i), 3432918353);
    h = (h << 13) | (h >>> 19);
  }
  return function(){
    h = Math.imul(h ^ (h >>> 16), 2246822507);
    h = Math.imul(h ^ (h >>> 13), 3266489909);
    h ^= h >>> 16;
    return (h >>> 0) / 4294967296;
  };
}
function encodeTeamCode(team){
  const payload = team.map(p=>`${p.speciesId}:${p.level}`).join(',');
  return Buffer.from(payload, 'utf8').toString('base64').replace(/=+$/,'');
}
function decodeTeamCode(code){
  if(!code) return null;
  let padded = code.trim();
  if(!padded) return null;
  while(padded.length % 4 !== 0) padded += '=';
  let payload;
  try{ payload = Buffer.from(padded, 'base64').toString('utf8'); } catch(e){ return null; }
  const parts = payload.split(',').filter(Boolean);
  if(parts.length===0 || parts.length>6) return null;
  const team = [];
  for(const part of parts){
    const bits = part.split(':');
    if(bits.length!==2) return null;
    const id = bits[0];
    const lvl = parseInt(bits[1],10);
    if(!SPECIES[id] || !Number.isFinite(lvl) || lvl<1 || lvl>200) return null;
    const inst = createInstance(id, lvl);
    if(!inst) return null;
    team.push(inst);
  }
  return team;
}

/* ---------------------------------------------------
   LÓGICA DA LIGA (mesma do jogo, portada pro servidor)
--------------------------------------------------- */
const LEAGUE_KEY = 'league_schedule_v1';
const CYCLE_INTERVAL_MS = 60 * 60 * 1000; // uma Liga nova por hora
const PHASE_MS = 5 * 60 * 1000;
const ROUND_KEYS = ['0','1','2'];

function computeNextScheduledTime(){
  const now = new Date();
  const target = new Date(now.getFullYear(), now.getMonth(), now.getDate(), now.getHours(), 0, 0, 0);
  if(target.getTime() <= now.getTime()){ target.setHours(target.getHours()+1); }
  return target.getTime();
}
function makeFreshCycle(scheduledTime){
  return {
    scheduledTime,
    status:'registering',
    registrants:[],
    leagues:null,
    leftover:null,
    qfTime:null, sfTime:null, finalTime:null
  };
}
function buildRounds(players){
  const qf = [];
  for(let i=0;i<4;i++){ qf.push({ a:players[i*2], b:players[i*2+1], winner:null, matchups:null, resolved:false }); }
  const sf = [
    { a:null, b:null, winner:null, matchups:null, resolved:false },
    { a:null, b:null, winner:null, matchups:null, resolved:false }
  ];
  const final = { a:null, b:null, winner:null, matchups:null, resolved:false };
  return { '0':qf, '1':sf, '2':[final] };
}
function shuffleWithSeed(arr, seedStr){
  const rng = makeSeededRng(seedStr);
  const a = arr.slice();
  for(let i=a.length-1;i>0;i--){
    const j = Math.floor(rng()*(i+1));
    [a[i],a[j]] = [a[j],a[i]];
  }
  return a;
}
async function syncLeaguePlayerLevels(playerRef, leveledTeam){
  if(!playerRef.uid || playerRef.slot==null) return;
  try{
    const ref = db.collection('users').doc(playerRef.uid).collection('saves').doc(String(playerRef.slot));
    const snap = await ref.get();
    if(!snap.exists) return;
    const saveData = snap.data();
    const currentTeam = saveData.team || [];
    const updatedTeam = currentTeam.map((p,i)=>{
      const leveled = leveledTeam[i];
      if(leveled && leveled.speciesId===p.speciesId){ return { ...p, level: leveled.level }; }
      return p;
    });
    await ref.set({ ...saveData, team: updatedTeam });
  } catch(e){ logger.error('Erro ao sincronizar levels da Liga pro save:', e); }
}
function resolveLeagueMatch(match, seedStr, pendingSyncs){
  const rng = makeSeededRng(seedStr);
  const teamA = decodeTeamCode(match.a.code);
  const teamB = decodeTeamCode(match.b.code);
  if(!teamA || !teamB){
    match.winner = teamA ? match.a : match.b;
    match.resolved = true;
    match.matchups = [];
    return;
  }
  const result = simulateGymBattle(teamA, teamB, rng);
  // mesma mecânica dos ginásios: pokémon que desmaiou ganha +1 level, e isso acompanha o treinador pra próxima fase
  // (e é gravado de volta no save real do jogador, mesmo que ele seja eliminado — a Cloud Function usa o Admin SDK,
  // então consegue escrever no save de QUALQUER jogador, diferente do cliente que só escreve no próprio)
  teamA.forEach(p=>{ if(p.hp<=0) p.level += 1; });
  teamB.forEach(p=>{ if(p.hp<=0) p.level += 1; });
  const updatedA = { name: match.a.name, code: encodeTeamCode(teamA), uid: match.a.uid, slot: match.a.slot };
  const updatedB = { name: match.b.name, code: encodeTeamCode(teamB), uid: match.b.uid, slot: match.b.slot };
  match.a = updatedA;
  match.b = updatedB;
  match.matchups = result.matchups; // mantém o log completo, pro botão "Assistir batalha" funcionar mesmo quando quem resolve é a Cloud Function
  match.winner = result.win ? updatedA : updatedB;
  match.resolved = true;
  pendingSyncs.push({ playerRef: updatedA, leveledTeam: teamA });
  pendingSyncs.push({ playerRef: updatedB, leveledTeam: teamB });
}
function tryAdvanceLeagueSchedule(data, pendingSyncs){
  let changed = false;
  const now = Date.now();

  if(!data.cycles.some(c=>c.status==='registering')){
    data.cycles.push(makeFreshCycle(computeNextScheduledTime()));
    changed = true;
  }

  // percorre uma "foto" da lista atual de ciclos, não a lista viva -- se um novo ciclo for criado
  // durante esta mesma passada, ele só é processado na próxima execução (1 minuto depois), evitando
  // um efeito cascata de vários ciclos avançando de uma vez só quando ninguém checa por um tempo
  const cyclesToProcess = data.cycles.slice();
  for(const cycle of cyclesToProcess){
    if(cycle.status==='registering'){
      if(now >= cycle.scheduledTime){
        const shuffled = shuffleWithSeed(cycle.registrants, 'draw-'+cycle.scheduledTime);
        const leagueCount = Math.floor(shuffled.length/8);
        const leagues = [];
        for(let i=0;i<leagueCount;i++){
          leagues.push({ id:i, rounds: buildRounds(shuffled.slice(i*8,i*8+8)), champion:null });
        }
        const leftover = shuffled.slice(leagueCount*8);
        cycle.leagues = leagues;
        cycle.leftover = leftover;
        cycle.qfTime = cycle.scheduledTime + PHASE_MS;
        cycle.sfTime = cycle.scheduledTime + PHASE_MS*2;
        cycle.finalTime = cycle.scheduledTime + PHASE_MS*3;
        cycle.status = leagueCount>0 ? 'drawn' : 'complete';
        changed = true;
        const nextCycle = makeFreshCycle(cycle.scheduledTime + CYCLE_INTERVAL_MS);
        nextCycle.registrants = leftover.slice(); // quem ficou de fora entra automaticamente na próxima Liga
        data.cycles.push(nextCycle);
      }
    } else if(cycle.status==='drawn'){
      const phaseTimes = [cycle.qfTime, cycle.sfTime, cycle.finalTime];
      for(let ri=0; ri<ROUND_KEYS.length; ri++){
        if(now < phaseTimes[ri]) break;
        const rk = ROUND_KEYS[ri];
        for(const league of cycle.leagues){
          const round = league.rounds[rk];
          for(let mi=0; mi<round.length; mi++){
            const match = round[mi];
            if(!match.resolved && match.a && match.b){
              resolveLeagueMatch(match, `${cycle.scheduledTime}-L${league.id}-R${ri}-M${mi}`, pendingSyncs);
              changed = true;
              if(ri+1 < ROUND_KEYS.length){
                const nextRound = league.rounds[ROUND_KEYS[ri+1]];
                const nextMatch = nextRound[Math.floor(mi/2)];
                if(mi%2===0){ nextMatch.a = match.winner; } else { nextMatch.b = match.winner; }
              } else {
                league.champion = match.winner;
              }
            }
          }
        }
      }
      if(cycle.leagues.length>0 && cycle.leagues.every(l=>l.champion)){
        cycle.status = 'complete';
        changed = true;
      }
    }
  }

  const completed = data.cycles.filter(c=>c.status==='complete').sort((a,b)=>a.scheduledTime-b.scheduledTime);
  if(completed.length>12){
    const toRemove = completed.slice(0, completed.length-12);
    data.cycles = data.cycles.filter(c=> !toRemove.includes(c));
    changed = true;
  }

  return changed;
}

/* ---------------------------------------------------
   FUNÇÃO AGENDADA — roda a cada minuto
--------------------------------------------------- */
exports.advanceLeague = onSchedule('every 1 minutes', async (event) => {
  const ref = db.collection('leagues').doc(LEAGUE_KEY);
  let pendingSyncs = [];
  let changedFlag = false;
  try{
    await db.runTransaction(async (tx)=>{
      const snap = await tx.get(ref);
      if(!snap.exists){ changedFlag = false; return; }
      const data = snap.data();
      pendingSyncs = []; // reseta a cada tentativa (a transação pode rodar de novo se houver conflito)
      const changed = tryAdvanceLeagueSchedule(data, pendingSyncs);
      changedFlag = changed;
      if(changed){
        data.updatedAt = Date.now();
        tx.set(ref, data);
      }
    });
  } catch(e){
    logger.error('Erro ao avançar a Liga:', e);
    return;
  }
  if(changedFlag){
    for(const {playerRef, leveledTeam} of pendingSyncs){
      await syncLeaguePlayerLevels(playerRef, leveledTeam);
    }
    logger.info('Liga avançada pelo Cloud Function.');
  } else {
    logger.info('Nada a avançar ainda.');
  }
});
